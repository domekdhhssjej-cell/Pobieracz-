# Pobieracz — Flask

## Uruchomienie lokalne

```bash
pip install -r requirements.txt
python app.py
```

Potem otwórz:
http://127.0.0.1:8080

## Hosting

Projekt wymaga hostingu obsługującego Python/Flask oraz wykonywanie procesu
serwera. Ustaw komendę startową:

gunicorn app:app

Uwaga: pobieranie powinno być używane wyłącznie dla materiałów, do których
masz odpowiednie prawa lub które są udostępnione do pobrania.
