from flask import Flask, request, render_template, send_file
import yt_dlp
import os
import tempfile

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/download", methods=["POST"])
def download():
    url = request.form.get("url", "").strip()

    if not url:
        return "Nie podano linku.", 400

    # Pobieranie materiałów, do których użytkownik ma prawo pobrania.
    temp_dir = tempfile.mkdtemp()
    output = os.path.join(temp_dir, "%(title)s.%(ext)s")

    options = {
        "format": "best[ext=mp4]/best",
        "outtmpl": output,
        "noplaylist": True,
        "quiet": True,
    }

    try:
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=True)
            filename = ydl.prepare_filename(info)

        return send_file(
            filename,
            as_attachment=True,
            download_name=os.path.basename(filename)
        )
    except Exception as e:
        return f"Błąd pobierania: {e}", 500

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
